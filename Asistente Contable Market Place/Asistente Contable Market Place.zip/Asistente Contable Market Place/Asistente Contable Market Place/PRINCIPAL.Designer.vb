﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PRINCIPAL
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PRINCIPAL))
        Me.panelContenedor = New System.Windows.Forms.Panel()
        Me.panel3 = New System.Windows.Forms.Panel()
        Me.label12 = New System.Windows.Forms.Label()
        Me.pictureBox4 = New System.Windows.Forms.PictureBox()
        Me.panel4 = New System.Windows.Forms.Panel()
        Me.panel9 = New System.Windows.Forms.Panel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.panel10 = New System.Windows.Forms.Panel()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.label10 = New System.Windows.Forms.Label()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.panel7 = New System.Windows.Forms.Panel()
        Me.label14 = New System.Windows.Forms.Label()
        Me.pictureBox5 = New System.Windows.Forms.PictureBox()
        Me.panel8 = New System.Windows.Forms.Panel()
        Me.panel11 = New System.Windows.Forms.Panel()
        Me.label8 = New System.Windows.Forms.Label()
        Me.pictureBox6 = New System.Windows.Forms.PictureBox()
        Me.panel12 = New System.Windows.Forms.Panel()
        Me.panel13 = New System.Windows.Forms.Panel()
        Me.label18 = New System.Windows.Forms.Label()
        Me.pictureBox7 = New System.Windows.Forms.PictureBox()
        Me.panel14 = New System.Windows.Forms.Panel()
        Me.label15 = New System.Windows.Forms.Label()
        Me.lblFecha = New System.Windows.Forms.Label()
        Me.lblhora = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.label6 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.BarraTitulo = New System.Windows.Forms.Panel()
        Me.iconminimizar = New System.Windows.Forms.PictureBox()
        Me.iconrestaurar = New System.Windows.Forms.PictureBox()
        Me.iconmaximizar = New System.Windows.Forms.PictureBox()
        Me.iconcerrar = New System.Windows.Forms.PictureBox()
        Me.btnMenu = New System.Windows.Forms.PictureBox()
        Me.MenuVertical = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.lblcorreo = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbluser = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.pictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.lblusuario = New System.Windows.Forms.Label()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.panelContenedor.SuspendLayout()
        Me.panel3.SuspendLayout()
        CType(Me.pictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel9.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel10.SuspendLayout()
        Me.Panel6.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel7.SuspendLayout()
        CType(Me.pictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel8.SuspendLayout()
        Me.panel11.SuspendLayout()
        CType(Me.pictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel13.SuspendLayout()
        CType(Me.pictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BarraTitulo.SuspendLayout()
        CType(Me.iconminimizar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconrestaurar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconmaximizar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iconcerrar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuVertical.SuspendLayout()
        CType(Me.pictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelContenedor
        '
        Me.panelContenedor.BackColor = System.Drawing.Color.White
        Me.panelContenedor.Controls.Add(Me.panel3)
        Me.panelContenedor.Controls.Add(Me.panel9)
        Me.panelContenedor.Controls.Add(Me.Panel6)
        Me.panelContenedor.Controls.Add(Me.panel7)
        Me.panelContenedor.Controls.Add(Me.panel11)
        Me.panelContenedor.Controls.Add(Me.panel13)
        Me.panelContenedor.Controls.Add(Me.label15)
        Me.panelContenedor.Controls.Add(Me.lblFecha)
        Me.panelContenedor.Controls.Add(Me.lblhora)
        Me.panelContenedor.Controls.Add(Me.Panel2)
        Me.panelContenedor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelContenedor.Location = New System.Drawing.Point(250, 45)
        Me.panelContenedor.Name = "panelContenedor"
        Me.panelContenedor.Size = New System.Drawing.Size(1034, 566)
        Me.panelContenedor.TabIndex = 9
        '
        'panel3
        '
        Me.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel3.Controls.Add(Me.label12)
        Me.panel3.Controls.Add(Me.pictureBox4)
        Me.panel3.Controls.Add(Me.panel4)
        Me.panel3.Location = New System.Drawing.Point(592, 121)
        Me.panel3.Name = "panel3"
        Me.panel3.Size = New System.Drawing.Size(110, 150)
        Me.panel3.TabIndex = 61
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.BackColor = System.Drawing.Color.DodgerBlue
        Me.label12.Font = New System.Drawing.Font("Century Gothic", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label12.ForeColor = System.Drawing.Color.White
        Me.label12.Location = New System.Drawing.Point(22, 4)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(60, 20)
        Me.label12.TabIndex = 15
        Me.label12.Text = "Ventas"
        '
        'pictureBox4
        '
        Me.pictureBox4.Image = CType(resources.GetObject("pictureBox4.Image"), System.Drawing.Image)
        Me.pictureBox4.Location = New System.Drawing.Point(11, 40)
        Me.pictureBox4.Name = "pictureBox4"
        Me.pictureBox4.Size = New System.Drawing.Size(80, 80)
        Me.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pictureBox4.TabIndex = 4
        Me.pictureBox4.TabStop = False
        '
        'panel4
        '
        Me.panel4.BackColor = System.Drawing.Color.DodgerBlue
        Me.panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel4.Location = New System.Drawing.Point(0, 0)
        Me.panel4.Name = "panel4"
        Me.panel4.Size = New System.Drawing.Size(108, 30)
        Me.panel4.TabIndex = 0
        '
        'panel9
        '
        Me.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel9.Controls.Add(Me.PictureBox3)
        Me.panel9.Controls.Add(Me.panel10)
        Me.panel9.Location = New System.Drawing.Point(19, 117)
        Me.panel9.Name = "panel9"
        Me.panel9.Size = New System.Drawing.Size(110, 150)
        Me.panel9.TabIndex = 66
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(12, 44)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(80, 80)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 1
        Me.PictureBox3.TabStop = False
        '
        'panel10
        '
        Me.panel10.BackColor = System.Drawing.Color.LightSeaGreen
        Me.panel10.Controls.Add(Me.label3)
        Me.panel10.Controls.Add(Me.label4)
        Me.panel10.Controls.Add(Me.label1)
        Me.panel10.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel10.Location = New System.Drawing.Point(0, 0)
        Me.panel10.Name = "panel10"
        Me.panel10.Size = New System.Drawing.Size(108, 30)
        Me.panel10.TabIndex = 0
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.ForeColor = System.Drawing.Color.SeaGreen
        Me.label3.Location = New System.Drawing.Point(24, 69)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(57, 20)
        Me.label3.TabIndex = 3
        Me.label3.Text = "15, 485"
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.ForeColor = System.Drawing.Color.White
        Me.label4.Location = New System.Drawing.Point(21, -50)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(67, 20)
        Me.label4.TabIndex = 2
        Me.label4.Text = "Clientes"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Century Gothic", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.ForeColor = System.Drawing.Color.White
        Me.label1.Location = New System.Drawing.Point(20, 4)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(67, 20)
        Me.label1.TabIndex = 0
        Me.label1.Text = "Clientes"
        '
        'Panel6
        '
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.label10)
        Me.Panel6.Controls.Add(Me.PictureBox8)
        Me.Panel6.Controls.Add(Me.Panel15)
        Me.Panel6.Location = New System.Drawing.Point(451, 120)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(110, 150)
        Me.Panel6.TabIndex = 62
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.BackColor = System.Drawing.Color.Red
        Me.label10.Font = New System.Drawing.Font("Century Gothic", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label10.ForeColor = System.Drawing.Color.White
        Me.label10.Location = New System.Drawing.Point(11, 4)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(91, 20)
        Me.label10.TabIndex = 15
        Me.label10.Text = "Inventarios"
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(15, 41)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(80, 80)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox8.TabIndex = 3
        Me.PictureBox8.TabStop = False
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.Red
        Me.Panel15.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel15.Location = New System.Drawing.Point(0, 0)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(108, 30)
        Me.Panel15.TabIndex = 0
        '
        'panel7
        '
        Me.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel7.Controls.Add(Me.pictureBox5)
        Me.panel7.Controls.Add(Me.panel8)
        Me.panel7.Location = New System.Drawing.Point(731, 122)
        Me.panel7.Name = "panel7"
        Me.panel7.Size = New System.Drawing.Size(110, 150)
        Me.panel7.TabIndex = 63
        '
        'label14
        '
        Me.label14.AutoSize = True
        Me.label14.BackColor = System.Drawing.Color.Crimson
        Me.label14.Font = New System.Drawing.Font("Century Gothic", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label14.ForeColor = System.Drawing.Color.White
        Me.label14.Location = New System.Drawing.Point(-4, 6)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(114, 20)
        Me.label14.TabIndex = 15
        Me.label14.Text = "Configuración"
        '
        'pictureBox5
        '
        Me.pictureBox5.Image = CType(resources.GetObject("pictureBox5.Image"), System.Drawing.Image)
        Me.pictureBox5.Location = New System.Drawing.Point(13, 41)
        Me.pictureBox5.Name = "pictureBox5"
        Me.pictureBox5.Size = New System.Drawing.Size(80, 80)
        Me.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pictureBox5.TabIndex = 5
        Me.pictureBox5.TabStop = False
        '
        'panel8
        '
        Me.panel8.BackColor = System.Drawing.Color.Crimson
        Me.panel8.Controls.Add(Me.label14)
        Me.panel8.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel8.Location = New System.Drawing.Point(0, 0)
        Me.panel8.Name = "panel8"
        Me.panel8.Size = New System.Drawing.Size(108, 30)
        Me.panel8.TabIndex = 0
        '
        'panel11
        '
        Me.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel11.Controls.Add(Me.label8)
        Me.panel11.Controls.Add(Me.pictureBox6)
        Me.panel11.Controls.Add(Me.panel12)
        Me.panel11.Location = New System.Drawing.Point(308, 119)
        Me.panel11.Name = "panel11"
        Me.panel11.Size = New System.Drawing.Size(110, 150)
        Me.panel11.TabIndex = 65
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.BackColor = System.Drawing.SystemColors.Highlight
        Me.label8.Font = New System.Drawing.Font("Century Gothic", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label8.ForeColor = System.Drawing.Color.White
        Me.label8.Location = New System.Drawing.Point(2, 2)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(104, 20)
        Me.label8.TabIndex = 15
        Me.label8.Text = "Proveedores"
        '
        'pictureBox6
        '
        Me.pictureBox6.Image = CType(resources.GetObject("pictureBox6.Image"), System.Drawing.Image)
        Me.pictureBox6.Location = New System.Drawing.Point(11, 42)
        Me.pictureBox6.Name = "pictureBox6"
        Me.pictureBox6.Size = New System.Drawing.Size(80, 80)
        Me.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pictureBox6.TabIndex = 6
        Me.pictureBox6.TabStop = False
        '
        'panel12
        '
        Me.panel12.BackColor = System.Drawing.SystemColors.Highlight
        Me.panel12.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel12.Location = New System.Drawing.Point(0, 0)
        Me.panel12.Name = "panel12"
        Me.panel12.Size = New System.Drawing.Size(108, 30)
        Me.panel12.TabIndex = 0
        '
        'panel13
        '
        Me.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel13.Controls.Add(Me.label18)
        Me.panel13.Controls.Add(Me.pictureBox7)
        Me.panel13.Controls.Add(Me.panel14)
        Me.panel13.Location = New System.Drawing.Point(865, 123)
        Me.panel13.Name = "panel13"
        Me.panel13.Size = New System.Drawing.Size(110, 150)
        Me.panel13.TabIndex = 64
        '
        'label18
        '
        Me.label18.AutoSize = True
        Me.label18.BackColor = System.Drawing.Color.OrangeRed
        Me.label18.Font = New System.Drawing.Font("Century Gothic", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label18.ForeColor = System.Drawing.Color.White
        Me.label18.Location = New System.Drawing.Point(21, 3)
        Me.label18.Name = "label18"
        Me.label18.Size = New System.Drawing.Size(73, 20)
        Me.label18.TabIndex = 15
        Me.label18.Text = "Servicios"
        '
        'pictureBox7
        '
        Me.pictureBox7.Image = CType(resources.GetObject("pictureBox7.Image"), System.Drawing.Image)
        Me.pictureBox7.Location = New System.Drawing.Point(14, 38)
        Me.pictureBox7.Name = "pictureBox7"
        Me.pictureBox7.Size = New System.Drawing.Size(80, 80)
        Me.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pictureBox7.TabIndex = 5
        Me.pictureBox7.TabStop = False
        '
        'panel14
        '
        Me.panel14.BackColor = System.Drawing.Color.OrangeRed
        Me.panel14.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel14.Location = New System.Drawing.Point(0, 0)
        Me.panel14.Name = "panel14"
        Me.panel14.Size = New System.Drawing.Size(108, 30)
        Me.panel14.TabIndex = 0
        '
        'label15
        '
        Me.label15.AutoSize = True
        Me.label15.Font = New System.Drawing.Font("Century Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.label15.Location = New System.Drawing.Point(15, 44)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(258, 30)
        Me.label15.TabIndex = 67
        Me.label15.Text = "Sumario del sistema:"
        '
        'lblFecha
        '
        Me.lblFecha.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblFecha.AutoSize = True
        Me.lblFecha.BackColor = System.Drawing.Color.Transparent
        Me.lblFecha.Font = New System.Drawing.Font("Century Gothic", 25.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFecha.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.lblFecha.Location = New System.Drawing.Point(859, 517)
        Me.lblFecha.Name = "lblFecha"
        Me.lblFecha.Size = New System.Drawing.Size(516, 40)
        Me.lblFecha.TabIndex = 59
        Me.lblFecha.Text = "Miercoles, 10  noviembre  2017"
        '
        'lblhora
        '
        Me.lblhora.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblhora.AutoSize = True
        Me.lblhora.BackColor = System.Drawing.Color.Transparent
        Me.lblhora.Font = New System.Drawing.Font("Century Gothic", 80.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhora.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblhora.Location = New System.Drawing.Point(588, 400)
        Me.lblhora.Name = "lblhora"
        Me.lblhora.Size = New System.Drawing.Size(467, 129)
        Me.lblhora.TabIndex = 58
        Me.lblhora.Text = "10:59:58"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.label6)
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Controls.Add(Me.Panel5)
        Me.Panel2.ForeColor = System.Drawing.Color.SeaGreen
        Me.Panel2.Location = New System.Drawing.Point(163, 118)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(110, 150)
        Me.Panel2.TabIndex = 60
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.BackColor = System.Drawing.Color.Green
        Me.label6.Font = New System.Drawing.Font("Century Gothic", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label6.ForeColor = System.Drawing.Color.White
        Me.label6.Location = New System.Drawing.Point(10, 4)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(89, 20)
        Me.label6.TabIndex = 15
        Me.label6.Text = "Empleados"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(14, 43)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(80, 80)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Green
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(108, 30)
        Me.Panel5.TabIndex = 0
        '
        'BarraTitulo
        '
        Me.BarraTitulo.BackColor = System.Drawing.Color.White
        Me.BarraTitulo.Controls.Add(Me.iconminimizar)
        Me.BarraTitulo.Controls.Add(Me.iconrestaurar)
        Me.BarraTitulo.Controls.Add(Me.iconmaximizar)
        Me.BarraTitulo.Controls.Add(Me.iconcerrar)
        Me.BarraTitulo.Controls.Add(Me.btnMenu)
        Me.BarraTitulo.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo.Location = New System.Drawing.Point(250, 0)
        Me.BarraTitulo.Name = "BarraTitulo"
        Me.BarraTitulo.Size = New System.Drawing.Size(1034, 45)
        Me.BarraTitulo.TabIndex = 8
        '
        'iconminimizar
        '
        Me.iconminimizar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.iconminimizar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.iconminimizar.Image = CType(resources.GetObject("iconminimizar.Image"), System.Drawing.Image)
        Me.iconminimizar.Location = New System.Drawing.Point(953, 5)
        Me.iconminimizar.Name = "iconminimizar"
        Me.iconminimizar.Size = New System.Drawing.Size(18, 18)
        Me.iconminimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.iconminimizar.TabIndex = 4
        Me.iconminimizar.TabStop = False
        '
        'iconrestaurar
        '
        Me.iconrestaurar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.iconrestaurar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.iconrestaurar.Image = CType(resources.GetObject("iconrestaurar.Image"), System.Drawing.Image)
        Me.iconrestaurar.Location = New System.Drawing.Point(979, 5)
        Me.iconrestaurar.Name = "iconrestaurar"
        Me.iconrestaurar.Size = New System.Drawing.Size(18, 18)
        Me.iconrestaurar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.iconrestaurar.TabIndex = 3
        Me.iconrestaurar.TabStop = False
        Me.iconrestaurar.Visible = False
        '
        'iconmaximizar
        '
        Me.iconmaximizar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.iconmaximizar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.iconmaximizar.Image = CType(resources.GetObject("iconmaximizar.Image"), System.Drawing.Image)
        Me.iconmaximizar.Location = New System.Drawing.Point(979, 5)
        Me.iconmaximizar.Name = "iconmaximizar"
        Me.iconmaximizar.Size = New System.Drawing.Size(18, 18)
        Me.iconmaximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.iconmaximizar.TabIndex = 2
        Me.iconmaximizar.TabStop = False
        '
        'iconcerrar
        '
        Me.iconcerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.iconcerrar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.iconcerrar.Image = CType(resources.GetObject("iconcerrar.Image"), System.Drawing.Image)
        Me.iconcerrar.Location = New System.Drawing.Point(1005, 5)
        Me.iconcerrar.Name = "iconcerrar"
        Me.iconcerrar.Size = New System.Drawing.Size(18, 18)
        Me.iconcerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.iconcerrar.TabIndex = 1
        Me.iconcerrar.TabStop = False
        '
        'btnMenu
        '
        Me.btnMenu.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMenu.Image = CType(resources.GetObject("btnMenu.Image"), System.Drawing.Image)
        Me.btnMenu.Location = New System.Drawing.Point(8, 6)
        Me.btnMenu.Name = "btnMenu"
        Me.btnMenu.Size = New System.Drawing.Size(35, 35)
        Me.btnMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnMenu.TabIndex = 0
        Me.btnMenu.TabStop = False
        '
        'MenuVertical
        '
        Me.MenuVertical.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.MenuVertical.Controls.Add(Me.Button1)
        Me.MenuVertical.Controls.Add(Me.Button7)
        Me.MenuVertical.Controls.Add(Me.lblcorreo)
        Me.MenuVertical.Controls.Add(Me.Label2)
        Me.MenuVertical.Controls.Add(Me.lbluser)
        Me.MenuVertical.Controls.Add(Me.Label5)
        Me.MenuVertical.Controls.Add(Me.pictureBox2)
        Me.MenuVertical.Controls.Add(Me.PictureBox10)
        Me.MenuVertical.Controls.Add(Me.Button8)
        Me.MenuVertical.Controls.Add(Me.lblusuario)
        Me.MenuVertical.Controls.Add(Me.PictureBox12)
        Me.MenuVertical.Controls.Add(Me.Button10)
        Me.MenuVertical.Controls.Add(Me.Button13)
        Me.MenuVertical.Controls.Add(Me.Button11)
        Me.MenuVertical.Controls.Add(Me.Button12)
        Me.MenuVertical.Dock = System.Windows.Forms.DockStyle.Left
        Me.MenuVertical.Location = New System.Drawing.Point(0, 0)
        Me.MenuVertical.Name = "MenuVertical"
        Me.MenuVertical.Size = New System.Drawing.Size(250, 611)
        Me.MenuVertical.TabIndex = 7
        '
        'Button1
        '
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(1, 326)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(250, 40)
        Me.Button1.TabIndex = 33
        Me.Button1.Text = "Empleados"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.White
        Me.Button7.Image = CType(resources.GetObject("Button7.Image"), System.Drawing.Image)
        Me.Button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button7.Location = New System.Drawing.Point(0, 418)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(250, 40)
        Me.Button7.TabIndex = 32
        Me.Button7.Text = "Servicios"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'lblcorreo
        '
        Me.lblcorreo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblcorreo.AutoSize = True
        Me.lblcorreo.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcorreo.ForeColor = System.Drawing.Color.White
        Me.lblcorreo.Location = New System.Drawing.Point(72, 553)
        Me.lblcorreo.Name = "lblcorreo"
        Me.lblcorreo.Size = New System.Drawing.Size(165, 17)
        Me.lblcorreo.TabIndex = 17
        Me.lblcorreo.Text = "elvisjeo2000@gmail.com"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(77, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(162, 24)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "Asistente Contable"
        '
        'lbluser
        '
        Me.lbluser.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lbluser.AutoSize = True
        Me.lbluser.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbluser.ForeColor = System.Drawing.Color.White
        Me.lbluser.Location = New System.Drawing.Point(72, 535)
        Me.lbluser.Name = "lbluser"
        Me.lbluser.Size = New System.Drawing.Size(109, 17)
        Me.lbluser.TabIndex = 16
        Me.lbluser.Text = "By Elvis Martinez"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Modern No. 20", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(77, 42)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 36)
        Me.Label5.TabIndex = 30
        Me.Label5.Text = "AC"
        '
        'pictureBox2
        '
        Me.pictureBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.pictureBox2.Image = Global.Asistente_Contable_Market_Place.My.Resources.Resources.ic_local_grocery_store_128_28460
        Me.pictureBox2.Location = New System.Drawing.Point(3, 508)
        Me.pictureBox2.Name = "pictureBox2"
        Me.pictureBox2.Size = New System.Drawing.Size(68, 66)
        Me.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pictureBox2.TabIndex = 15
        Me.pictureBox2.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = Global.Asistente_Contable_Market_Place.My.Resources.Resources._1486564180_finance_financial_report_81493
        Me.PictureBox10.Location = New System.Drawing.Point(1, 27)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(70, 75)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox10.TabIndex = 29
        Me.PictureBox10.TabStop = False
        '
        'Button8
        '
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.White
        Me.Button8.Image = CType(resources.GetObject("Button8.Image"), System.Drawing.Image)
        Me.Button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button8.Location = New System.Drawing.Point(0, 462)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(250, 40)
        Me.Button8.TabIndex = 28
        Me.Button8.Text = "Configuración"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'lblusuario
        '
        Me.lblusuario.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblusuario.AutoSize = True
        Me.lblusuario.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblusuario.ForeColor = System.Drawing.Color.White
        Me.lblusuario.Location = New System.Drawing.Point(72, 518)
        Me.lblusuario.Name = "lblusuario"
        Me.lblusuario.Size = New System.Drawing.Size(98, 17)
        Me.lblusuario.TabIndex = 14
        Me.lblusuario.Text = "Administrador"
        '
        'PictureBox12
        '
        Me.PictureBox12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox12.Location = New System.Drawing.Point(0, 6)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(254, 119)
        Me.PictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox12.TabIndex = 22
        Me.PictureBox12.TabStop = False
        '
        'Button10
        '
        Me.Button10.FlatAppearance.BorderSize = 0
        Me.Button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.White
        Me.Button10.Image = CType(resources.GetObject("Button10.Image"), System.Drawing.Image)
        Me.Button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button10.Location = New System.Drawing.Point(0, 372)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(250, 40)
        Me.Button10.TabIndex = 26
        Me.Button10.Text = "Proveedores"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.FlatAppearance.BorderSize = 0
        Me.Button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button13.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.ForeColor = System.Drawing.Color.White
        Me.Button13.Image = CType(resources.GetObject("Button13.Image"), System.Drawing.Image)
        Me.Button13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button13.Location = New System.Drawing.Point(0, 188)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(250, 40)
        Me.Button13.TabIndex = 23
        Me.Button13.Text = "Productos"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.FlatAppearance.BorderSize = 0
        Me.Button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.ForeColor = System.Drawing.Color.White
        Me.Button11.Image = CType(resources.GetObject("Button11.Image"), System.Drawing.Image)
        Me.Button11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button11.Location = New System.Drawing.Point(0, 280)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(250, 40)
        Me.Button11.TabIndex = 25
        Me.Button11.Text = "Clientes"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.FlatAppearance.BorderSize = 0
        Me.Button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button12.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.ForeColor = System.Drawing.Color.White
        Me.Button12.Image = CType(resources.GetObject("Button12.Image"), System.Drawing.Image)
        Me.Button12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button12.Location = New System.Drawing.Point(0, 234)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(250, 40)
        Me.Button12.TabIndex = 24
        Me.Button12.Text = "Ventas"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'PRINCIPAL
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1284, 611)
        Me.Controls.Add(Me.panelContenedor)
        Me.Controls.Add(Me.BarraTitulo)
        Me.Controls.Add(Me.MenuVertical)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "PRINCIPAL"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PRINCIPAL"
        Me.panelContenedor.ResumeLayout(False)
        Me.panelContenedor.PerformLayout()
        Me.panel3.ResumeLayout(False)
        Me.panel3.PerformLayout()
        CType(Me.pictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel9.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel10.ResumeLayout(False)
        Me.panel10.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel7.ResumeLayout(False)
        CType(Me.pictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel8.ResumeLayout(False)
        Me.panel8.PerformLayout()
        Me.panel11.ResumeLayout(False)
        Me.panel11.PerformLayout()
        CType(Me.pictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel13.ResumeLayout(False)
        Me.panel13.PerformLayout()
        CType(Me.pictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BarraTitulo.ResumeLayout(False)
        CType(Me.iconminimizar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconrestaurar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconmaximizar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iconcerrar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnMenu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuVertical.ResumeLayout(False)
        Me.MenuVertical.PerformLayout()
        CType(Me.pictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents panelContenedor As System.Windows.Forms.Panel
    Private WithEvents panel3 As System.Windows.Forms.Panel
    Private WithEvents label12 As System.Windows.Forms.Label
    Private WithEvents pictureBox4 As System.Windows.Forms.PictureBox
    Private WithEvents panel4 As System.Windows.Forms.Panel
    Private WithEvents panel9 As System.Windows.Forms.Panel
    Private WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Private WithEvents panel10 As System.Windows.Forms.Panel
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents Panel6 As System.Windows.Forms.Panel
    Private WithEvents label10 As System.Windows.Forms.Label
    Private WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Private WithEvents Panel15 As System.Windows.Forms.Panel
    Private WithEvents panel7 As System.Windows.Forms.Panel
    Private WithEvents label14 As System.Windows.Forms.Label
    Private WithEvents pictureBox5 As System.Windows.Forms.PictureBox
    Private WithEvents panel8 As System.Windows.Forms.Panel
    Private WithEvents panel11 As System.Windows.Forms.Panel
    Private WithEvents label8 As System.Windows.Forms.Label
    Private WithEvents pictureBox6 As System.Windows.Forms.PictureBox
    Private WithEvents panel12 As System.Windows.Forms.Panel
    Private WithEvents panel13 As System.Windows.Forms.Panel
    Private WithEvents label18 As System.Windows.Forms.Label
    Private WithEvents pictureBox7 As System.Windows.Forms.PictureBox
    Private WithEvents panel14 As System.Windows.Forms.Panel
    Private WithEvents label15 As System.Windows.Forms.Label
    Private WithEvents lblFecha As System.Windows.Forms.Label
    Private WithEvents lblhora As System.Windows.Forms.Label
    Private WithEvents Panel2 As System.Windows.Forms.Panel
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Private WithEvents Panel5 As System.Windows.Forms.Panel
    Private WithEvents BarraTitulo As System.Windows.Forms.Panel
    Private WithEvents iconminimizar As System.Windows.Forms.PictureBox
    Private WithEvents iconrestaurar As System.Windows.Forms.PictureBox
    Private WithEvents iconmaximizar As System.Windows.Forms.PictureBox
    Private WithEvents iconcerrar As System.Windows.Forms.PictureBox
    Private WithEvents btnMenu As System.Windows.Forms.PictureBox
    Private WithEvents MenuVertical As System.Windows.Forms.Panel
    Private WithEvents Button1 As System.Windows.Forms.Button
    Private WithEvents Button7 As System.Windows.Forms.Button
    Private WithEvents lblcorreo As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents lbluser As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents pictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Private WithEvents Button8 As System.Windows.Forms.Button
    Private WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Private WithEvents Button10 As System.Windows.Forms.Button
    Private WithEvents Button13 As System.Windows.Forms.Button
    Private WithEvents Button11 As System.Windows.Forms.Button
    Private WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Private WithEvents lblusuario As System.Windows.Forms.Label
End Class
